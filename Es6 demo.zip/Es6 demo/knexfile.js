// import {config as dotenvconfig} from 'dotenv';
// dotenvconfig();
require('dotenv').config();

module.exports = {
  
    client: process.env.DB_CLIENT,
  
    connection: {
      host: process.env.DB_HOST,
      user:process.env.DB_USERNAME,
      password:process.env.DB_PASSWORD,
      database:process.env.DB_DATABASE,
      charset:'utf8'
     
    },
    
    useNullAsDefault:true,
    migrations:{
      directory:`${__dirname}/migration`,
    },
    seeds:{
      directory:`${__dirname}/migration`,
    }
    
};
