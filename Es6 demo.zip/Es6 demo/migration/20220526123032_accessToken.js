
exports.up = function(knex) {
    return knex.schema.createTable('accesstoken',(table)=>{
        table.text('id'),
        table.integer('empId').references('employee.empId').unsigned().onDelete('CASCADE'),
        table.tinyint('revoked'),
        table.timestamp('expireIn'),
        table.timestamp('createAt').defaultTo(knex.fn.now()),
        table.timestamp('updatedAt').defaultTo(knex.fn.now())
  })
};

exports.down = function(knex) {
    return knex.schema.dropTable('accessToken')
};
