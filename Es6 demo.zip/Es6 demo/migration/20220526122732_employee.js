
exports.up = (knex)=> {
    return knex.schema.createTable('employee',(table)=>{
        table.increments('empId').primary(),
        table.string('name'),
        table.string('address'),
        table.string('email').unique(),
        table.string('password'),
        table.enum('countryCode',['+91','+1','+81']).notNullable(),
        table.string('phone').unique(),
        table.integer('salary'),
        table.integer('pf'),
        table.string('profile'),
        table.timestamp('createAt').defaultTo(knex.fn.now()),
        table.timestamp('updatedAt').defaultTo(knex.fn.now())
   })
};


exports.down = (knex)=> {
    return knex.schema.dropTable('employee');
};
