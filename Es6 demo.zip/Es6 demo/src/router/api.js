import express from 'express'
var router = express.Router();
import path from 'path';
import multer from 'multer';
import asyncWrap from 'express-async-wrapper';
import AuthEmp from '../employee_auth/auth.controller';
import auth from '../auth/autn';
import validator from '../validation/employee.validation';
import register from '../employee_auth/dto/register.schema';
import EmployeeDetails from '../employee/employee.controller';
import employeeHobbi from '../employeehobies/hobbies.controller';
import login from '../employee_auth/dto/login.schema';
import hobbies from '../employeehobies/dto/hobbies.schema';
import update from '../employee/dto/employee.update.schema'


var storage = multer.diskStorage({
    destination: (req, res, cd) => {
        cd(null, './public/uploads')
    },
    filename: function (req, file, cd) {
        cd(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
})
var upload = multer({ storage: storage })

//Auth Api
router.post('/register', validator.body(register), (AuthEmp.register));
router.post('/login', validator.body(login), asyncWrap(AuthEmp.logIn));
router.get('/logout', auth, asyncWrap(AuthEmp.logout));

// Employee Api
router.get('/employee/Page', auth, asyncWrap(EmployeeDetails.employeePage));
router.get('/employee',auth,asyncWrap(EmployeeDetails.employee));
router.patch('/employee/:empId', auth,upload.single('profile'),validator.body(update),asyncWrap(EmployeeDetails.updateEmp));
router.delete('/employee/:empId', auth, asyncWrap(EmployeeDetails.deleteEmployee));



//Employeehobies
router.post('/hobbies', auth, validator.body(hobbies), asyncWrap(employeeHobbi.hobbiesAdd));
router.get('/hobbies', auth, asyncWrap(employeeHobbi.employeeHobbies));
router.put('/hobbie/:id', auth, validator.body(hobbies), asyncWrap(employeeHobbi.hobbiesUpdate));
router.delete('/hobbie/:id', auth, asyncWrap(employeeHobbi.hobbiesDelete));

export default router;