import joi from 'joi'

const login=joi.object({
        email:joi.string().email().required().messages({'string.empty':'Email required'}),
        password:joi.string().required().messages({'string.empty':'Password required'})

})

export default login;