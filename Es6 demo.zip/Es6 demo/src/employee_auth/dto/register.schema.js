import joi from 'joi';

const register=joi.object({
        name:joi.string().max(25).required().messages({'string.empty':'Name required'}),
        address:joi.string().required().$.messages({'string.empty':'Address required'}),
        email:joi.string().email().required().messages({'string.empty':'Email required'}),
        password:joi.string().required().messages({'string.empty':'Password required'}),
        countryCode:joi.string().required().messages({'string.empty':'countryCode required'}),
        phone:joi.string().regex(/^[6-9]\d{9}$/).required().messages({'string.empty':'Phone required'}),
        salary:joi.number().integer().empty(" ").required().messages({'string.empty':'Salary required'})

    })


export default register;