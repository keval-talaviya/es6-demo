import knex from "../config/knexfile";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import moment from "moment";
import { randomBytes } from "crypto";
import EmployeeResource from "./resource/resource ";
require("dotenv").config();

class AuthServices {
  async registerEmp(body) {
    const email = body.email;
    const employee = await knex("employee").where("email", email).first();

    if (!employee) {
      const password = body.password;
      const pass = await bcrypt.hash(password, 10);
      const pf = (body.salary * 12) / 100;
      const [empId] = await knex("employee").insert({
        name: body.name,
        address: body.address,
        email: body.email,
        password: pass,
        countryCode: body.countryCode,
        phone: body.phone,
        salary: body.salary,
        pf: pf,
      });
      const data = await knex("employee").where({ empId: empId }).first();
      if (data) {
        const pass = await bcrypt.compare(password, data.password);
        if (pass) {
          const privateKey = process.env.PRIVATEKEY;
          const params = {
            empId: data.empId,
            jti: randomBytes(32).toString("hex"),
          };
          const token = jwt.sign(params, privateKey, {
            expiresIn: process.env.EXPIRESIN,
          });
          const decode = jwt.verify(token, privateKey);
          const expiresAt = moment.unix(decode["exp"]).toDate();
          await knex("accesstoken").insert({
            id: decode.jti,
            empId: decode.empId,
            revoked: false,
            expireIn: expiresAt,
          });
          return { ...new EmployeeResource(data), token };
        } else {
          throw new Error("Not found!");
        }
      } else {
        throw new Error("Employee not found");
      }
    } else {
      // console.log('error');
    }
  }

  async loginEmp(body) {
    const email = body.email;
    const password = body.password;
    return await knex("employee")
      .where({ email: email })
      .first()
      .then(async (data) => {
        if (data) {
          const pass = await bcrypt.compare(password, data.password);
          if (pass) {
            const privateKey = process.env.PRIVATEKEY;
            const params = {
              empId: data.empId,
              jti: randomBytes(32).toString("hex"),
            };
            const token = jwt.sign(params, privateKey, {
              expiresIn: process.env.EXPIRESIN,
            });
            const decode = jwt.verify(token, privateKey);
            const expiresAt = moment.unix(decode["exp"]).toDate();
            await knex("accesstoken").insert({
              id: decode.jti,
              empId: decode.empId,
              revoked: false,
              expireIn: expiresAt,
            });
            return { ...new EmployeeResource(data), token };
          } else {
            throw new Error("Not found!");
          }
        } else {
          throw new Error("Wrong email and/or password");
        }
      });
  }

  async logoutEmp(user) {
    await knex("accessToken").where({ id: user.jti }).update({
      revoked: true,
    });
  }
}

export default AuthServices;
