require("dotenv").config();
import AuthServices from "./auth.services";

class AuthEmp {
  static async register(req, res, next) {
    const data = await new AuthServices().registerEmp(req.body);

    return res.status(200).json({ data: data });
  }

  static async logIn(req, res, next) {
    const data = await new AuthServices().loginEmp(req.body);
    return res.status(200).json({ data: data });
  }

  static async logout(req, res, next) {
    const data = await new AuthServices().logoutEmp(req.employee);
    return res.json({ message: "Employee Logout" });
  }
}

export default AuthEmp;
