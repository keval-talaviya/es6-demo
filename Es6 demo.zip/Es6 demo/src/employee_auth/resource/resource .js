

export default class EmployeeResource {
    constructor(data) {
        this.empId = data.empId,
            this.name = data.name,
            this.address = data.address,
            this.email = data.email,
            this.countryCode = data.countryCode,
            this.phone = data.phone,
            this.salary = data.salary,
            this.pf = data.pf,
            this.profile =`http://localhost:3000/uploads/${data.profile}`,
            this.createAt = new Date().getTime(data.createAt),
            this.updatedAt = new Date().getTime(data.updatedAt)
          
    }
}