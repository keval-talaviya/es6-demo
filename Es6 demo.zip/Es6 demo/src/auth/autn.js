require('dotenv').config();
import knex from '../config/knexfile';
import jwt from 'jsonwebtoken';

export default async (req, res, next) => {
    if (req.headers && req.headers.authorization) {
        const token = req.headers.authorization.split(' ')[1];
        try {
            const decode = jwt.verify(token, process.env.PRIVATEKEY);
            const employee = await knex('employee').where({ empId: decode.empId }).first();
            const accessToken = await knex('accessToken').where({ id: decode.jti }).first();

            if (!employee || !accessToken || accessToken.revoked === 1) {
                return res.status(401).send({ success: false, message: 'unauthorized access!' });
            }
            req.employee = { ...employee, jti: decode.jti };
            next()
        } catch (error) {
            return res.status(500).send({ success: false, message: 'Internal server error!' });
        }
    } else {
        return res.status(401).send({ success: false, message: 'unauthorized access!' });
    }
}