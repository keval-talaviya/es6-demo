
export default (err,req,res,next)=>{
    if(err && err.error && err.error.isJoi){
        // console.log(err.error.message);
        return res.status(400).json({
            type: err.type,
            // message: err.error.isJoi.toString()
            message:err.error.message
        });
    }else{
        next()
    }
}