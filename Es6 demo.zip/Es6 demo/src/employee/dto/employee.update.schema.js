import joi from 'joi'

const update=joi.object({
    name:joi.string().required().messages({'string.empty':'Name required'}),
    address:joi.string().required().messages({'string.empty':'Address required'}),
    password:joi.string().required().messages({'string.empty':'Password required'}),
    salary:joi.number().integer().required().messages({'string.empty':'Salary required'})
    // profile:joi.string().required().messages({'string.empty':'Profile required'})
})

export default update