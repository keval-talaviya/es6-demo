import knex from "../config/knexfile";
import bcrypt from "bcrypt";
import EmployeeResource from "../employee_auth/resource/resource ";
import EmployeeAllData from "./resource /resource";

class EmployeeServices {
  async employeeUpdate(body, file, user) {
    const empId = user.empId;
    const password = body.password;
    const pass = await bcrypt.hash(password, 10);
    const pf = (body.salary * 12) / 100;
    const data = await knex("employee").where("empId", empId).update({
      name: body.name,
      address: body.address,
      password: pass,
      salary: body.salary,
      pf: pf,
      profile: file.filename,
    });

    return data;
  }

  async employeeDelete(params) {
    const value = await knex("employee")
      .where({ empId: parseInt(params.empId) })
      .first();
    if (!value) {
      return res.status(400).send({
        message: "Employee Not Found",
      });
    }
    const data = await knex("employee")
      .where({ empId: parseInt(params.empId) })
      .delete();
    return new EmployeeResource(data);
  }

  async page(query) {
    const page = parseInt(query.page);
    const limit = parseInt(query.limit);

    const value = await knex("employee").paginate({
      perPage: limit,
      currentPage: page,
      isLengthAware: true,
    });
    return value.data.map((data) => new EmployeeResource(data));
  }

  async employeeData(user) {
    const empId = user.empId;
    const data = await knex("employee").where("empId", empId).first();

    const ditalies = await knex("employeehobbies")
      .where("empId", empId)
      .select();
    const hobbie = ditalies.map((value) => new EmployeeAllData(value));
    return { ...new EmployeeResource(data), hobbie };
  }
}

export default EmployeeServices;
