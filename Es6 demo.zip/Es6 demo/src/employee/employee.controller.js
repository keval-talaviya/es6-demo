import knex from '../config/knexfile';
import bcrypt from 'bcrypt';
import EmployeeServices from './employee.services';

class EmployeeDetails {

    static async updateEmp(req, res, next) {
        const data = await new EmployeeServices().employeeUpdate(req.body, req.file, req.employee);
        return res.status(200).send({message: "successfuly update" })
    }

    static async deleteEmployee(req, res, next) {
        const data = await new EmployeeServices().employeeDelete(req.params);
        return res.status(200).send({ message: 'Employee Successfully delete' })
    }

    static async employeePage(req, res, next) {
        const data = await new EmployeeServices().page(req.query);
        return res.status(200).json({data:data});
    }

    static async employee(req, res, next) {
        const value = await new EmployeeServices().employeeData(req.employee);
        return res.status(200).send({data:value});
    }


}

export default EmployeeDetails