
export default class EmployeeAllData{
    constructor(value){
        this.hobbieId=value.id,
        this.hobbies=value.hobbies,
        this.createAt = new Date().getTime(value.createAt),
        this.updatedAt = new Date().getTime(value.updatedAt)
    }
}