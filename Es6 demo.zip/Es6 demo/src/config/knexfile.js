import knex from 'knex';
import {attachPaginate} from 'knex-paginate';
import knexfile from '../../knexfile';
attachPaginate()
const config=knexfile;

export default knex(config);