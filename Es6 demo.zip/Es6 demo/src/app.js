import express from 'express';
import {config as dotenvconfig} from 'dotenv';
dotenvconfig();
import bodyParer from 'body-parser';
import YAML from 'yamljs';
import swaggerUI from 'swagger-ui-express';
import router from './router/api';
import path from 'path';
import errorHandler from './common/error.handler';

const app = express()
app.use(express.json());
app.use(bodyParer.json());
app.use(bodyParer.urlencoded({ extended:true}));
app.use('/api/v1',router);

const swaggerDocument=YAML.load(path.join(__dirname,'../swagger.yaml'));
app.use('/api-docs',(req,res,next)=>{
    swaggerDocument.host=req.get('host');
    req.swaggerDoc=swaggerDocument;
    next();
},swaggerUI.serve,swaggerUI.setup());


app.use("/",express.static(`${__dirname}../../public`));
// app.use('/uploads', express.static('uoploads'));

app.use(errorHandler);
app.listen(process.env.PORT,()=>{
    console.log(`server start ${process.env.PORT}`);
})
