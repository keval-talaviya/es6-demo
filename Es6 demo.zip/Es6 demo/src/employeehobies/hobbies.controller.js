import knex from "../config/knexfile";
import HobbiesServices from "./hobbies.services";

class EmployeeHobbies {
  static async hobbiesAdd(req, res, next) {
    const value = await new HobbiesServices().employeeHobbies(
      req.employee,
      req.body
    );
    return res.status(200).send({
      message: "Employee hobbies created",
    });
  }
  static async employeeHobbies(req, res, next) {
    const value = await new HobbiesServices().hobbiesData(req.employee);
    return res.status(200).json({ data: value });
  }

  static async hobbiesUpdate(req, res, next) {
    const value = await new HobbiesServices().update(req.params, req.body);
    return res.status(200).send({ message: "Employee hobbies updated " });
  }

  static async hobbiesDelete(req, res, next) {
    const value = await new HobbiesServices().deleteHobbi(req.params);
    return res.status(200).json({ message: "Employeehobbies deleted" });
  }
}

export default EmployeeHobbies;
