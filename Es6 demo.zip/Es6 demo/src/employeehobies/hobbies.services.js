import knex from "../config/knexfile";
import HobbiesResource from "./resource /resource";

class HobbiesServices {
  async employeeHobbies(user, body) {
    const empId = user.empId;
    const data = await knex("employeehobbies").insert({
      empId: empId,
      hobbies: body.hobbies,
    });
    return data;
  }

  async hobbiesData(user) {
    const empId = user.empId;
    const value = await knex("employeehobbies").where("empId", empId).select();
    return value.map((data) => new HobbiesResource(data));
  }

  async update(params, body) {
    const data = await knex("employeehobbies").where({ id: params.id }).update({
      hobbies: body.hobbies,
    });
    return data;
  }

  async deleteHobbi(params) {
    console.log(params.id);
    const data = await knex("employeehobbies")
      .where({ id: params.id })
      .delete();
    return data;
  }
}

export default HobbiesServices;
