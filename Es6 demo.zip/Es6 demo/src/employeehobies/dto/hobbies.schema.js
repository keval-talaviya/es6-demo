import joi from 'joi'

const hobbies=joi.object({
    hobbies:joi.string().required().messages({'string.empty':'Hobbies required'})
})

export default hobbies;