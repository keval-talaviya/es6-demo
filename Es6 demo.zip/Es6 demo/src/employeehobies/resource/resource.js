

export default class HobbiesResource{
    constructor(data) {
        this.hobbieId=data.id
        this.empId = data.empId,
        this.hobbies=data.hobbies,
        this.createAt = new Date().getTime(data.createAt),
        this.updatedAt = new Date().getTime(data.updatedAt)
    }
} 