require('dotenv').config()

module.exports = {

    client: process.env.DB_CONNECTION,
    port:3306,
    connection: {
      host:  process.env.DB_HOST,
      user: process.env.DB_USERNAME,
      database: process.env.DB_DATABASE,
    },
    pool: {
      min: 2,
      max: 10
    },
    migrations: {
      directory: `${__dirname}/src/common/model`
    }
  }


