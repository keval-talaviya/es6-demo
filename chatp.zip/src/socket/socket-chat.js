import knex from "../common/config/database.config";
import moment from "moment";
import { storeAsSync } from "../common/helper";

export default async (io) => {
  // Socket connection

  io.on("connection", async (socket) => {
    socket.on("join room", async (body, room) => {
      socket.leave(body.senderId.toString());
      await knex("users")
        .update({
          socketId: socket.id,
          isActive: 1,
        })
        .where("id", body.senderId);
      if (body.senderId && body.receiverId) {
        await knex("chat_history")
          .update({ isRead: true })
          .where("senderId", parseInt(body.receiverId))
          .where("receiverId", parseInt(body.senderId));
      }

      const user = await knex("users")
        .where("id", parseInt(body.senderId))
        .first();
        if(user){
          socket.broadcast.emit("status online", {
            isActive: 1,
            senderId: body.senderId,
            userId: user.userId,
          });
        }

      socket.on("chat message", async (data) => {
        const date=new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"})
        if (data.groupId) {
          const [id] = await knex("chat_history").insert({
            senderId: parseInt(data.senderId),
            groupId: parseInt(data.groupId),
            message: data.message,
            messageType: parseInt(data.messageType),
            groupMessageSeen: data.senderId,
            messgeCreatedAt: await moment(date).format("YYYY-MM-DD HH:mm:ss"),
          });

          const userData = await knex("users")
            .where("id", parseInt(data.senderId))
            .first();

          const groupData = await knex("groups")
            .where("id", parseInt(data.groupId))
            .first();
          io.emit("group chat message", {
            messageId: id,
            message: data.message,
            messageType: parseInt(data.messageType),
            senderId: parseInt(data.senderId),
            groupId: parseInt(data.groupId),
            senderProfile: userData.profilePicture,
            senderFirstname: userData.firstName,
            senderLastName: userData.lastName,
            name: groupData.name,
            groupIcon: groupData.groupIcon,
            groupUid: groupData.groupId,
          });

          //

          io.emit("group list", {
            groupUid: groupData.groupId,
            senderId: data.senderId,
          });
        } else {
          const [id] = await knex("chat_history").insert({
            senderId: parseInt(data.senderId),
            receiverId: parseInt(data.receiverId),
            message: data.message,
            isRead: false,
            messageType: parseInt(data.messageType),
            messgeCreatedAt: await moment(date).format("YYYY-MM-DD HH:mm:ss"),
          });

          const senderUser = await knex("users")
            .where("id", parseInt(data.senderId))
            .first();
          const receiverUser = await knex("users")
            .where("id", parseInt(data.receiverId))
            .first();

          io.to(senderUser.socketId)
            .to(receiverUser.socketId)
            .emit("chat message", {
              messageId: id,
              message: data.message,
              senderId: data.senderId,
              receiverId: data.receiverId,
              receiverProfile: receiverUser.profilePicture,
              senderProfile: senderUser.profilePicture,
              name: `${senderUser.firstName} ${senderUser.lastName}`,
              userId: senderUser.userId,
              receiverUserId: receiverUser.userId,
            });

          const unReadMessage = await knex("chat_history")
            .where("senderId", parseInt(data.senderId))
            .where("receiverId", parseInt(data.receiverId))
            .where("isRead", false);
          io.to(receiverUser.socketId).emit("user list", {
            userId: senderUser.userId,
            unReadMessage: unReadMessage.length,
          });
        }
      });

      socket.on("media", async (data) => {

        const date=new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"})
        if (data.groupId) {
          const [id] = await knex("chat_history").insert({
            senderId: parseInt(data.senderId),
            groupId: parseInt(data.groupId),
            message: data.message,
            messageType: parseInt(data.messageType),
            filePath: data.filename,
            fileSize: data.fileSize,
            updatedAt: moment().add(1440, "minutes").format("YYYY-MM-DD HH:mm"),
            messgeCreatedAt: await moment(date).format("YYYY-MM-DD HH:mm:ss"),
          });
          const userData = await knex("users")
            .where("id", parseInt(data.senderId))
            .first();
          const groupData = await knex("groups")
            .where("id", parseInt(data.groupId))
            .first();

          io.emit("group chat media", {
            filePath: `/storage/${data.filename}`,
            messageId: id,
            message: data.message,
            isRead: false,
            messageType: parseInt(data.messageType),
            fileSize: data.fileSize,
            senderId: data.senderId,
            groupId: data.groupId,
            senderProfile: userData.profilePicture,
            senderFirstname: userData.firstName,
            senderLastName: userData.lastName,
            name: groupData.name,
            groupIcon: groupData.groupIcon,
            groupUid: groupData.groupId,
          });

          io.emit("group list", {
            groupUid: groupData.groupId,
            senderId: data.senderId,
          });
        } else {
         
          const [id] = await knex("chat_history").insert({
            senderId: parseInt(data.senderId),
            receiverId: parseInt(data.receiverId),
            message: data.message,
            isRead: false,
            messageType: parseInt(data.messageType),
            filePath: data.filename,
            fileSize: data.fileSize,
            updatedAt: moment().add(1440, "minutes").format("YYYY-MM-DD HH:mm"),
            messgeCreatedAt: await moment(date).format("YYYY-MM-DD HH:mm:ss"),
          });
          const senderUser = await knex("users")
            .where("id", parseInt(data.senderId))
            .first();
          const receiverUser = await knex("users")
            .where("id", parseInt(data.receiverId))
            .first();

          io.to(senderUser.socketId)
            .to(receiverUser.socketId)
            .emit("media", {
              filePath: `/storage/${data.filename}`,
              messageId: id,
              message: data.message,
              messageType: parseInt(data.messageType),
              fileSize: data.fileSize,
              senderId: data.senderId,
              receiverId: data.receiverId,
              receiverProfile: receiverUser.profilePicture,
              senderProfile: senderUser.profilePicture,
              name: `${senderUser.firstName} ${senderUser.lastName}`,
              userId: senderUser.userId,
              receiverUserId: receiverUser.userId,
            });

          const unReadMessage = await knex("chat_history")
            .where("senderId", parseInt(data.senderId))
            .where("receiverId", parseInt(data.receiverId))
            .where("isRead", false);
          io.to(receiverUser.socketId).emit("user list", {
            userId: senderUser.userId,
            unReadMessage: unReadMessage.length,
          });
        }
      });

      // Read message
      socket.on("read message", async (data) => {
        if (data.messageId) {
          await knex("chat_history")
            .update({ isRead: true })
            .where("id", data.messageId);
        }
      });

      socket.on("group mesage read", async (data) => {
        if (data.messageId) {
          const message = await knex("chat_history")
            .where("id", parseInt(data.messageId))
            .first();
          const messageSeenUser = message.groupMessageSeen
            ? message.groupMessageSeen.split(",")
            : [];
          messageSeenUser.push(data.senderId);
          await knex("chat_history")
            .update({
              groupMessageSeen: messageSeenUser.toString(),
            })
            .where("id", parseInt(data.messageId));
        }
        const message = await knex("chat_history")
          .where("groupId", parseInt(data.groupId))
          .limit(50)
          .orderBy("id", "desc");

        await Promise.all(
          message.map(async (messageData) => {
            const messageSeenUser = messageData.groupMessageSeen
              ? messageData.groupMessageSeen.split(",")
              : [];
            if (!messageSeenUser.includes(data.senderId)) {
              messageSeenUser.push(data.senderId);
            }
            await knex("chat_history")
              .update({
                groupMessageSeen: messageSeenUser.toString(),
              })
              .where("id", messageData.id);
          })
        );
      });
      // Socket Disconnecte
      socket.on("disconnect", async () => {
        socket.leave(body.senderId.toString());

        await knex("users")
          .update({
            isActive: 0,
            disconnectedAt: await moment().format("YYYY-MM-DD HH:mm:ss"),
          })
          .where("id", body.senderId);

        const user = await knex("users")
          .where("id", parseInt(body.senderId))
          .first();
          if(user){

            socket.broadcast.emit("status online", {
              isActive: 0,
              senderId: body.senderId,
              userId: user.userId,
            });
          }
      });
    });
  });
};
