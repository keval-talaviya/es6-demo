import express from "express";
import { createServer as httpCreateServer } from "http";
import { createServer as httpsCreateServer } from "https";
import { Server } from "socket.io";
import bodyParser from "body-parser";
import { existsSync, unlinkSync } from "fs";
import passport from "passport";
import path from "path";
import session from "express-session";
import adminRouter from "./router/admin.router";
import chatSocket from "./socket/socket-chat";
import fileUpload from "express-fileupload";
import cron from "node-cron";
import knex from "./common/config/database.config";
import moment from "moment";

require("dotenv").config();

const app = express();

app.use(express.json({ extend: true }));
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(fileUpload());
app.use(passport.initialize());
app.set("view engine", "ejs");
app.set("views", path.join(`${__dirname}../../src`, "views"));
app.use(express.static(path.join(__dirname, "../public")));
app.use(
  session({ secret: "hjs89d", resave: "false", saveUninitialized: "true" })
);

app.use("/", adminRouter);

let server;
if (process.env.IS_SSL_ENABLE === "true") {
  // SSL certificate path
  const options = {
    key: fs.readFileSync(`${process.env.SSL_CERT_BASE_PATH}/privkey.pem`),
    cert: fs.readFileSync(`${process.env.SSL_CERT_BASE_PATH}/fullchain.pem`),
  };
  server = httpsCreateServer(options, app);
} else {
  server = httpCreateServer(app);
}

// Socket
const io = new Server(server, {
  /* options */
});
chatSocket(io);

server.listen(process.env.PORT, () => {
  console.log(`Listening on (HTTP/HTTPS) ${process.env.PORT}`);
});

cron.schedule("* * * * *", async () => {
  const a=[2,3,4]
  const data = await knex("chat_history").whereIn("messageType", a);

  await data.map(async (files) => {
    var startDate = moment().format("YYYY-MM-DD HH:mm");
    const timestampStartDate = moment(startDate).unix();
    const filesTime = moment(files.updatedAt).unix();
    if (filesTime < timestampStartDate) {
      if (
        existsSync(
          path.join(`${__dirname}/../public/storage/${files.filePath}`)
        )
      ) {
        unlinkSync(
          path.join(`${__dirname}/../public/storage/${files.filePath}`)
        );
      }
      await knex("chat_history").where("id", files.id).delete();
    }
  });
});
