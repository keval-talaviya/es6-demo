import { Router } from "express";
import asyncWrap from "express-async-wrapper";
import authController from "../admin/auth/auth.controller";
import homeController from "../admin/home/home.controller";
import authentication from "../common/middlewares/admin-authentication.middleware";
import userProfileController from "../admin/user-profile/user-profile.controller";
import groupController from "../admin/group/group.controller";
import userController from "../admin/user-data/user.controller";
import { storeAsSync } from "../common/helper";

const router = Router();

// Authentication
router
  .get("/", asyncWrap(authController.loginIndex))
  .post("/login", asyncWrap(authController.login))
  .get("/sign-up", asyncWrap(authController.signUpIndex))
  .post("/sign-up", asyncWrap(authController.signUp))
  .get("/password-reset", asyncWrap(authController.passwordReset))
  .post("/password-reset", asyncWrap(authController.passwordResetMail))
  .get("/forgot-password/:token/:id", asyncWrap(authController.forgotPassword))
  .get("/logout", authentication, asyncWrap(authController.logout));

// Home
router
  .get("/home", authentication, asyncWrap(homeController.homeIndex))
  .get("/home/:id", authentication, asyncWrap(homeController.homeChatUse))
  .get("/group/:id", authentication, asyncWrap(homeController.groupChatUse))
  .get(
    "/message-chat/:id",
    authentication,
    asyncWrap(homeController.messageList)
  )
  .get(
    "/group-message/:id",
    authentication,
    asyncWrap(homeController.groupMaessageList)
  );

// Profile
router
  .get(
    "/profile",
    authentication,
    asyncWrap(userProfileController.profileIndex)
  )
  .post(
    "/profile",
    authentication,
    asyncWrap(userProfileController.profileDetailsUpdate)
  );

// Change password
router
  .get(
    "/change-password",
    authentication,
    asyncWrap(userProfileController.changePasswordIndex)
  )
  .post(
    "/change-password",
    authentication,
    asyncWrap(userProfileController.changepassword)
  );

// Group Create
router
  .get("/group-add", authentication, asyncWrap(groupController.groupCreate))
  .post(
    "/group-add",
    authentication,
    asyncWrap(groupController.groupDetailsAdd)
  )
  .get("/group-list", authentication, asyncWrap(groupController.groupList))
  .get(
    "/group-update/:id",
    authentication,
    asyncWrap(groupController.groupUpdatePage)
  )
  .post(
    "/group-update",
    authentication,
    asyncWrap(groupController.groupDetailsUpdate)
  )
  .get(
    "/group-delete/:id",
    authentication,
    asyncWrap(groupController.groupDelete)
  );

// User sevices
router
  .get("/user-list", authentication, asyncWrap(userController.userDataList))
  .get(
    "/profile-update/:id",
    authentication,
    asyncWrap(userController.userDetailsUpdate)
  )
  .post("/profile-update", authentication, asyncWrap(userController.userUpdate))
  .get(
    "/user-delete/:id",
    authentication,
    asyncWrap(userController.userDelete)
  );

// Media file shar
router.post("/media", async (req, res) => {
  let messageType = "3";
  if (
    req.files.upload_file.mimetype.includes("image/avif") ||
    req.files.upload_file.mimetype.includes("image/jpg") ||
    req.files.upload_file.mimetype.includes("image/jpeg") ||
    req.files.upload_file.mimetype.includes("image/png") ||
    req.files.upload_file.mimetype.includes("image/svg") ||
    req.files.upload_file.mimetype.includes("image/gif")
  ) {
    messageType = "2";
  }
  if (
    req.files.upload_file.mimetype.includes("application/pdf") ||
    req.files.upload_file.mimetype.includes("application/octet-stream") ||
    req.files.upload_file.mimetype.includes("application/js") ||
    req.files.upload_file.mimetype.includes("application/json") ||
    req.files.upload_file.mimetype.includes("application/doc") ||
    req.files.upload_file.mimetype.includes("application/xml") ||
    req.files.upload_file.mimetype.includes("application/docm") ||
    req.files.upload_file.mimetype.includes("application/docx") ||
    req.files.upload_file.mimetype.includes("text/xml") ||
    req.files.upload_file.mimetype.includes("application/vnd.openxmlformats-officedocument.wordprocessingml.document") ||
    req.files.upload_file.mimetype.includes("application/x-zip-compressed") ||
    req.files.upload_file.mimetype.includes("text/html") ||
    req.files.upload_file.mimetype.includes("image/svg+xml")  

  ) {
    messageType = "3";
  }
  if (
    req.files.upload_file.mimetype.includes("video/mp4") ||
    req.files.upload_file.mimetype.includes("video/mp3")
  ) {
    messageType = "4";
  }

  function formatBytes(a, b = 2) {
    if (!+a) return "0 Bytes";
    const c = 0 > b ? 0 : b,
      d = Math.floor(Math.log(a) / Math.log(1024));
    return `${parseFloat((a / Math.pow(1024, d)).toFixed(c))} ${
      ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][d]
    }`;
  }
  const fileSize = await formatBytes(req.files.upload_file.size);

  if (req.files.upload_file.size <= 500000001) {
    const fileName = await storeAsSync(
      "media",
      req.files.upload_file.data,
      req.files.upload_file.mimetype
    );
    const name = req.files.upload_file.name;
    return res.json({
      messageType: messageType,
      fileName: fileName,
      fileSize: fileSize,
      name: name,
    });
  }

  return res.json({
    messageType: messageType,
    fileName: null,
    fileSize: fileSize,
    name: "File to large",
  });
});

export default router;
