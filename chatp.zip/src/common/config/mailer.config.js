import nodemailer from "nodemailer";
import ejs from "ejs";

require("dotenv").config();

class Mail {
  static async sendEmail(email, subject, template, data) {
    const transporter = nodemailer.createTransport({
      pool: true,
      host: process.env.MAIL_HOST,
      port: +process.env.MAIL_PORT,
      // secure: process.env.MAIL_ENCRYPTION ,
      auth: {
        user: process.env.MAIL_USERNAME,
        pass: process.env.MAIL_PASSWORD,
      },
    });
    const text = await ejs.renderFile(data, { template });
    await transporter.sendMail({
      from: process.env.MAIL_USERNAME,
      to: email,
      subject,
      html: text,
    });
  }
}

export default Mail;
