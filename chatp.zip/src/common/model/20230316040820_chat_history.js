exports.up = function (knex) {
  return knex.schema.createTable("chat_history", (table) => {
    table.increments("id").unsigned().primary();
    table
      .integer("senderId")
      .references("users.id")
      .unsigned()
      .onDelete("CASCADE");
    table
      .integer("receiverId")
      .references("users.id")
      .unsigned()
      .onDelete("CASCADE");
    table.integer("groupId").nullable();
    table.binary("message").nullable();
    table.string("filePath").nullable();
    table.string("fileSize").nullable();
    table.string("mediaType").nullable();
    table.text("mediaBuffer").nullable();
    table.integer("messageType").nullable();
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").nullable();
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable("chat_history");
};
