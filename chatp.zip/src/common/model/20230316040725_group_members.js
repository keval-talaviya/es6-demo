exports.up = function (knex) {
  return knex.schema.createTable("group_members", (table) => {
    table.increments("id").unsigned().primary();
    table
      .integer("groupId")
      .references("groups.id")
      .unsigned()
      .onDelete("CASCADE");
    table
      .integer("userId")
      .references("users.id")
      .unsigned()
      .onDelete("CASCADE");
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").nullable();
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable("group_members");
};
