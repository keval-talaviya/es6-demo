exports.up = function (knex) {
  return knex.schema.createTable("groups", (table) => {
    table.increments("id").unsigned().primary();
    table.string("groupId").nullable();
    table.string("name");
    table.string("groupIcon").nullable();
    table
      .integer("createrId")
      .references("users.id")
      .unsigned()
      .onDelete("CASCADE");
    table.string("socketId").nullable();
    table.timestamp("createdAt").defaultTo(knex.fn.now());
    table.timestamp("updatedAt").nullable();
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable("groups");
};
