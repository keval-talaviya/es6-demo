exports.up = function (knex) {
  return knex.schema
    .createTable("users", (table) => {
      table.increments("id").unsigned().primary();
      table.string("userId").nullable();
      table.enum("role", ["Admin", "Employee"]).nullable();
      table.string("email");
      table.string("password").nullable();
      table.string("firstName").nullable();
      table.string("lastName").nullable();
      table.string("phoneNumber").nullable();
      table.string("profilePicture").nullable();
      table.string("socketId").nullable();
      table.boolean("isActive").nullable();
      table.string("forgotPasswordToken").nullable();
      table.timestamp("disconnectedAt").nullable();
      table.timestamp("forgotPasswordExpiredAt").nullable();
      table.timestamp("createdAt").defaultTo(knex.fn.now());
      table.timestamp("updatedAt").nullable();
    })
    .then(async () =>
      knex("users").insert([
        {
          role: "Admin",
          userId: "00b52d42-93f7-478c-a3bc-113a19eb1124",
          email: "sahajanand@gmail.com",
          password:
            "$2b$10$dydpzoayEL4Ua2LxsqBuhew1ZuLMenKOskpiI.hgeYncNqxKd5CyK", // password
          firstName: "Sahajanand",
          lastName: "Infotech",
        },
      ])
    );
};

exports.down = function (knex) {
  return knex.schema.dropTable("users");
};
