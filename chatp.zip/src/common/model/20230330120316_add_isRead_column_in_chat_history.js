exports.up = (knex) =>
  knex.schema.table("chat_history", (table) => {
    table.boolean("isRead").after("message");
    table.timestamp("messgeCreatedAt").nullable();
    table.text("groupMessageSeen").after("isRead");
  });

exports.down = (knex) =>
  knex.schema.table("chat_history", (table) => {
    table.dropColumn("isRead");
    table.dropColumn("messgeCreatedAt");
    table.dropColumn("groupMessageSeen");
  });
