import JWT from "jsonwebtoken";

require("dotenv").config();

const adminAuthentication = async (req, res, next) => {
  if (req.session.token) {
    JWT.verify(req.session.token, process.env.APP_KEY, async (err, decoded) => {
      if (err) {
        if (req.xhr) {
          return res.status(401).send("unauthorized");
        }
        return res.redirect("/");
      }
      req.user = decoded;

      next();
    });
  } else {
    if (req.xhr) {
      return res.status(401).send("unauthorized");
    }
    return res.redirect("/");
  }
};

export default adminAuthentication;
