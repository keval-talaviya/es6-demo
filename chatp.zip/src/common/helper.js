import { existsSync, mkdirSync, writeFileSync, unlinkSync } from "fs";
import { v4 as uuidv4 } from "uuid";
import mime from "mime";

require("dotenv").config();

export const storeAsSync = (dir, buffer, mimetype) => {
  const storageDir = "public/storage";
  let i = "doc";
  if (mimetype.includes("application/x-zip-compressed")) {
    i = "zip";
  }
  if (mimetype.includes("image/avif")) {
    i = "avif";
  }
  if (mimetype.includes("image/jpg")) {
    i = "jpg";
  }
  if (mimetype.includes("application/pdf")) {
    i = "pdf";
  }
  if (mimetype.includes("text/xml")) {
    i = "xml";
  }
  if (mimetype.includes("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
    i = "doc";
  }
  if (mimetype.includes("application/xml")) {
    i = "zip";
  }
  if (mimetype.includes("video/mp4")) {
    i = "xml";
  }
  const fileName = `${dir}/${uuidv4()}.${i}`;

  const storageDirExists = existsSync(storageDir);
  if (!storageDirExists) mkdirSync(storageDir);
  const exists = existsSync(`${storageDir}/${dir}`);
  if (!exists) mkdirSync(`${storageDir}/${dir}`);

  writeFileSync(`${storageDir}/${fileName}`, buffer);

  return fileName;
};

export const castToStorage = (string) =>
  string ? constants.baseUrl(`storage/${string}`) : null;

/**
 * delete file
 *  @param {string} file
 * @returns
 */
export const deleteFile = (file) => {
  const filePath = `./public/storage/${file}`;
  if (existsSync(filePath)) {
    unlinkSync(filePath);
  }
  return true;
};
