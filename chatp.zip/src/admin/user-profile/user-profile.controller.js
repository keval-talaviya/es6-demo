import knex from "../../common/config/database.config";
import bcrypt from "bcrypt";
import { existsSync, unlinkSync } from "fs";
import path from "path";
import { storeAsSync } from "../../common/helper";

class UserProfileController {
  /**
   * Profile-page
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async profileIndex(req, res) {
    const user = await knex("users").where("id", req.user.id).first();
    const userCount = await knex("users").whereNot("id", req.user.id);
    const userList = await knex("users").whereNot("id", req.user.id).limit(5);
    const groupMembers = await knex("group_members").where(
      "userId",
      req.user.id
    );

    return res.render("user-profile/profile", {
      data: user,
      userCount: userCount.length,
      userList: userList,
      groupMembers: groupMembers,
    });
  }

  /**
   * Usre profile details update
   * @param {*} req
   * @param {*} res
   */
  async profileDetailsUpdate(req, res) {
    if (req.files !== null) {
      if (req.files.backgroundImage) {
        const user = await knex("users").where("id", req.user.id).first();
        if (
          existsSync(
            path.join(
              `${__dirname}../../../../public/storage${user.secondaryImage}`
            )
          )
        ) {
          unlinkSync(
            path.join(
              `${__dirname}../../../../public/storage${user.secondaryImage}`
            )
          );
        }
        const file = await storeAsSync(
          "backgroundImage",
          req.files.backgroundImage.data,
          req.files.backgroundImage.mimetype
        );
        await knex("users")
          .update({
            secondaryImage: `/${file}`,
          })
          .where("id", req.user.id);
      }

      if (req.files.profileImage) {
        const user = await knex("users").where("id", req.user.id).first();
        if (
          existsSync(
            path.join(
              `${__dirname}../../../../public/storage${user.profilePicture}`
            )
          )
        ) {
          unlinkSync(
            path.join(
              `${__dirname}../../../../public/storage${user.profilePicture}`
            )
          );
        }
        const file = await storeAsSync(
          "profileImage",
          req.files.profileImage.data,
          req.files.profileImage.mimetype
        );
        await knex("users")
          .update({
            profilePicture: `/${file}`,
          })
          .where("id", req.user.id);
      }
    }

    return res.redirect("/profile");
  }

  /**
   * Change password page
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async changePasswordIndex(req, res) {
    const user = await knex("users").where("id", req.user.id).first();
    const userCount = await knex("users").whereNot("id", req.user.id);
    const userList = await knex("users").whereNot("id", req.user.id).limit(5);
    const groupMembers = await knex("group_members").where(
      "userId",
      req.user.id
    );
    return res.render("user-profile/change-password", {
      data: user,
      userCount: userCount.length,
      userList: userList,
      groupMembers: groupMembers,
    });
  }

  /**
   * Change password
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async changepassword(req, res) {
    const user = await knex("users").where("id", req.user.id).first();

    const hashedPasswordMatch = await bcrypt.compare(
      req.body.oldPassword,
      user.password
    );

    if (!hashedPasswordMatch) {
      return res.render("error/change-password");
    }

    const newPasswordMatch = await bcrypt.compare(
      req.body.newPassword,
      user.password
    );

    if (newPasswordMatch) {
      return res.render("error/old-new-password-match");
    }

    if (req.body.newPassword !== req.body.confirmPassword) {
      return res.render("error/new-password");
    }
    await knex("users")
      .update({
        password: await bcrypt.hash(req.body.newPassword, 10),
      })
      .where("id", req.user.id);

    return res.render("error/change-password-message");
  }
}
export default new UserProfileController();
