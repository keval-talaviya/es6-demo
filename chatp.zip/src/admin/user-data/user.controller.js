import knex from "../../common/config/database.config";
import bcrypt from "bcrypt";
import { existsSync, unlinkSync } from "fs";
import path from "path";
import { storeAsSync } from "../../common/helper";

class UserController {
  /**
   * User list
   * @param {*} req
   * @param {*} res
   */
  async userDataList(req, res) {
    const user = await knex("users").where("id", req.user.id).first();
    const userCount = await knex("users");
    const userList = await knex("users").whereNot("id", req.user.id).limit(5);
    const groupMembers = await knex("group_members").where(
      "userId",
      req.user.id
    );

    return res.render("user-profile/user-list", {
      data: user,
      userCount: userCount.length,
      userList: userList,
      groupMembers: groupMembers,
      users: userCount,
    });
  }

  /**
   * user details update
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async userDetailsUpdate(req, res) {
    const authUser = await knex("users").where("id", req.user.id).first();
    const user = await knex("users").where("userId", req.params.id).first();
    const userCount = await knex("users").whereNot("id", req.user.id);
    const userList = await knex("users").whereNot("id", req.user.id).limit(5);
    const groupMembers = await knex("group_members").where(
      "userId",
      req.user.id
    );

    return res.render("user-profile/profile-update", {
      authUser: authUser,
      data: user,
      userCount: userCount.length,
      userList: userList,
      groupMembers: groupMembers,
    });
  }

  /**
   * User details update
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async userUpdate(req, res) {
    if (req.files) {
      const user = await knex("users")
        .where("userId", parseInt(req.body.id))
        .first();
      if (
        existsSync(
          path.join(
            `${__dirname}../../../../public/storage${user.profilePicture}`
          )
        )
      ) {
        unlinkSync(
          path.join(
            `${__dirname}../../../../public/storage${user.profilePicture}`
          )
        );
      }
      const file = await storeAsSync(
        "profileImage",
        req.files.profileImage.data,
        req.files.profileImage.mimetype
      );
      await knex("users")
        .update({
          profilePicture: `/${file}`,
        })
        .where("userId", req.body.id);
    }

    if (req.body.password) {
      await knex("users")
        .update({
          password: await bcrypt.hash(req.body.password, 10),
        })
        .where("userId", req.body.id);
    }
    await knex("users")
      .update({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        role: req.body.role,
      })
      .where("userId", req.body.id);
    return res.redirect("/user-list");
  }

  /**
   * User delete
   * @param {*} req
   * @param {*} res
   */
  async userDelete(req, res) {
    const user = await knex("users").where("userId", req.params.id).first();
    if (
      existsSync(
        path.join(`${__dirname}../../../../public/storage${user.groupIcon}`)
      )
    ) {
      unlinkSync(
        path.join(`${__dirname}../../../../public/storage${user.groupIcon}`)
      );
    }
    await knex("users").where("userId", req.params.id).delete();

    return res.redirect("/user-list");
  }
}
export default new UserController();
