import moment from "moment";
import knex from "../../common/config/database.config";
import { v4 as uuidv4 } from "uuid";
import { storeAsSync } from "../../common/helper";
import { existsSync, unlinkSync } from "fs";
import path from "path";

class GroupController {
  /**
   * Group ceate
   * @param {*} req
   * @param {*} res
   */
  async groupCreate(req, res) {
    const user = await knex("users").where("id", req.user.id).first();
    const userList = await knex("users").whereNot("id", req.user.id);
    const userCount = await knex("users").whereNot("id", req.user.id);
    const userListData = await knex("users")
      .whereNot("id", req.user.id)
      .limit(5);
    const groupMembers = await knex("group_members").where(
      "userId",
      req.user.id
    );

    return res.render("group/index", {
      data: user,
      userList: userList,
      userCount: userCount.length,
      userListData: userListData,
      groupMembers: groupMembers,
    });
  }

  /**
   * Group details add
   * @param {*} req
   * @param {*} res
   */
  async groupDetailsAdd(req, res) {
    const file = await storeAsSync(
      "groupIcon",
      req.files.groupIcon.data,
      req.files.groupIcon.mimetype
    );
    const [id] = await knex("groups").insert({
      groupId: await uuidv4(),
      name: req.body.groupName,
      groupIcon: `/${file}`,
      createrId: req.user.id,
    });
    await knex("group_members").insert({
      groupId: id,
      userId: parseInt(req.user.id),
    });
    if (req.body.user.length != 1) {
      await req.body.user.map(async (ids) => {
        await knex("group_members").insert({
          groupId: id,
          userId: parseInt(ids),
        });
      });
    } else {
      await knex("group_members").insert({
        groupId: id,
        userId: parseInt(req.body.user),
      });
    }

    return res.redirect("/home");
  }

  /**
   * group List
   * @param {*} req
   * @param {*} res
   */
  async groupList(req, res) {
    const user = await knex("users").where("id", req.user.id).first();
    const userCount = await knex("users").whereNot("id", req.user.id);
    const userList = await knex("users").whereNot("id", req.user.id).limit(5);
    const groupMembers = await knex("group_members").where(
      "userId",
      req.user.id
    );
    const groupData = await knex("groups")
      .select(
        "groups.id",
        "groups.groupId",
        "groups.name",
        "groups.groupIcon",
        "groups.createrId",
        "users.firstName",
        "users.lastName"
      )
      .leftJoin("users", "users.id", "groups.createrId");
    const groupList = [];
    await Promise.all(
      await groupData.map(async (data) => {
        const members = await knex("group_members").where("groupId", data.id);
        const a = await { ...data, members: members.length };

        groupList.push(a);
      })
    );
    return res.render("user-profile/group-list", {
      data: user,
      userCount: userCount.length,
      userList: userList,
      groupMembers: groupMembers,
      users: userCount,
      groupList: groupList,
    });
  }

  /**
   * Group update from
   * @param {*} req
   * @param {*} res
   */
  async groupUpdatePage(req, res) {
    const authUser = await knex("users")
      .where("id", parseInt(req.user.id))
      .first();
    const group = await knex("groups").where("groupId", req.params.id).first();
    const data = await knex("users");
    const members = await knex("group_members").where("groupId", group.id);

    const userList = [];

    await Promise.all(
      data.map(async (a) => {
        const groupMember = await knex("group_members")
          .where("groupId", group.id)
          .where("userId", a.id)
          .first();
        if (groupMember) {
          const b = { ...a, isSelect: true };
          userList.push(b);
          return;
        }
        const c = { ...a, isSelect: false };
        userList.push(c);
        return;
      })
    );

    return res.render("user-profile/group-update", {
      authUser: authUser,
      group: group,
      userList: userList,
      members: members,
    });
  }

  /**
   * Group details update
   * @param {*} req
   * @param {*} res
   */
  async groupDetailsUpdate(req, res) {
    if (req.files) {
      const group = await knex("groups")
        .where("id", parseInt(req.body.id))
        .first();
      if (
        existsSync(
          path.join(`${__dirname}../../../../public/storage${group.groupIcon}`)
        )
      ) {
        unlinkSync(
          path.join(`${__dirname}../../../../public/storage${group.groupIcon}`)
        );
      }
      const file = await storeAsSync(
        "groupIcon",
        req.files.groupIcon.data,
        req.files.groupIcon.mimetype
      );
      await knex("groups")
        .update({
          groupIcon: `/${file}`,
        })
        .where("id", req.body.id);
    }
    await knex("groups")
      .update({
        name: req.body.groupName,
      })
      .where("id", req.body.id);

    await knex("group_members").where("groupId", req.body.id).delete();

    if (req.body.user.length != 1) {
      await req.body.user.map(async (ids) => {
        await knex("group_members").insert({
          groupId: req.body.id,
          userId: parseInt(ids),
        });
      });
    } else {
      await knex("group_members").insert({
        groupId: req.body.id,
        userId: parseInt(req.body.user),
      });
    }
    return res.redirect("/group-list");
  }

  /**
   * Group delete
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async groupDelete(req, res) {
    const group = await knex("groups").where("groupId", req.params.id).first();
    if (
      existsSync(
        path.join(`${__dirname}../../../../public/storage${group.groupIcon}`)
      )
    ) {
      unlinkSync(
        path.join(`${__dirname}../../../../public/storage${group.groupIcon}`)
      );
    }
    await knex("groups").where("groupId", req.params.id).delete();
    return res.redirect("/group-list");
  }
}
export default new GroupController();
