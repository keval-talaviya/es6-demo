import knex from "../../common/config/database.config";

class authService {}

export default new authService();
