import authService from "./auth.service";
import bcrypt from "bcrypt";
import knex from "../../common/config/database.config";
import jwt from "jsonwebtoken";
import { randomBytes } from "crypto";
import moment from "moment";
import path from "path";
import Mail from "../../common/config/mailer.config";
import { v4 as uuidv4 } from "uuid";

require("dotenv").config();

class authController {
  /**
   * Login Page
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async loginIndex(req, res) {
    const { token } = req.session;
    if (token) {
      return res.redirect("/home");
    }
    return res.render("auth/login");
  }

  /**
   * Login details
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async login(req, res) {
    const isUserExisting = await knex("users")
      .where("email", req.body.email)
      .first();
    if (!isUserExisting) {
      return res.render("error/user-not-found");
    }
    const hashedPasswordMatch = await bcrypt.compare(
      req.body.password,
      isUserExisting.password
    );
    if (hashedPasswordMatch) {
      const payload = {
        id: isUserExisting.id,
        email: isUserExisting.email,
      };

      const token = await jwt.sign(payload, process.env.APP_KEY, {
        expiresIn: "365days",
      });

      req.session.token = token;

      return res.redirect("/home");
    }
    return res.render("error/password-invalid");
  }

  /**
   * Sign up page
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async signUpIndex(req, res) {
    return res.render("auth/sign-up");
  }

  /**
   * sign up details
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async signUp(req, res) {
    const isSignUpUser = await knex("users")
      .where("email", req.body.email)
      .first();
    if (isSignUpUser) {
      return res.render("error/conflict");
    }
    if (req.body.password !== req.body.confirmPassword) {
      return res.render("error/bad-request");
    }
    const [id] = await knex("users").insert({
      role: req.body.role,
      userId: await uuidv4(),
      email: req.body.email,
      firstname: req.body.firstname,
      lastname: req.body.lastname,
      phoneNumber: req.body.phoneNumber,
      password: await bcrypt.hash(req.body.password, 10),
    });

    return res.redirect("/home");
  }

  /**
   * password reset page
   * @param {*} req
   * @param {*} res
   */
  async passwordReset(req, res) {
    return res.render("auth/password-reset");
  }

  /**
   * password reset mail sent
   * @param {*} req
   * @param {*} res
   */
  async passwordResetMail(req, res) {
    const userdata = await knex("users").where("email", req.body.email).first();
    if (!userdata) {
      return res.render("error/bad-request");
    }
    await knex("users")
      .update({
        forgotPasswordToken: randomBytes(32).toString("hex"),
        forgotPasswordExpiredAt: moment()
          .add(10, "minutes")
          .format("YYYY-MM-DD HH:mm:ss"),
      })
      .where({ id: userdata.id });

    const user = await knex("users").where("email", req.body.email).first();
    const link = `${process.env.APP_URL}:${process.env.PORT}/forgot-password/${user.forgotPasswordToken}/${user.id}`;
    const data = path.join(
      `${__dirname}/../../views/password-reset/template.ejs`
    );
    await Mail.sendEmail(user.email, "Forgot-password", link, data);

    return res.render("password-reset/mail-sent");
  }

  async forgotPassword(req, res) {
    const user = await knex("users")
      .where("id", parseInt(req.params.id))
      .where("forgotPasswordToken", req.params.token);
    if (
      moment().format("YYYY-MM-DD HH:mm:ss") <= user.forgotPasswordExpiredAt
    ) {
    }
  }

  /**
   * User logout
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async logout(req, res) {
    await req.session.destroy(function (err) {
      if (err) {
        console.error(err);
        return res.sendStatus(500);
      }
    });
    return res.redirect("/");
  }
}
export default new authController();
