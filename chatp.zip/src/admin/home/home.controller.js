import moment from "moment";
import knex from "../../common/config/database.config";

class HomeController {
  /**
   * Home page open
   * @param {*} req
   * @param {*} res
   * @returns
   */
  async homeIndex(req, res) {
    const user = await knex("users").where("id", req.user.id).first();
    const userData = await knex("users").whereNot("id", req.user.id);
    const lastMessageSenderUser = await knex("chat_history")
      .where("receiverId", user.id)
      .pluck("senderId")
      .orderBy("id", "desc");
    const lastMessageSenderIds = [];
    const firstSenderUser = [];
    const lastSenderUser = [];

    await Promise.all(
      lastMessageSenderUser.map(async (k) => {
        if (!lastMessageSenderIds.includes(k)) {
          lastMessageSenderIds.push(k);
        }
      })
    );

    await Promise.all(
      lastMessageSenderIds.map(async (a) => {
        await Promise.all(
          userData.map(async (b) => {
            if (a === b.id) {
              const unReadMessageCount = await knex("chat_history")
                .where("receiverId", user.id)
                .where("senderId", b.id)
                .where("isRead", false);
              firstSenderUser.push({
                ...b,
                unReadMessage: unReadMessageCount.length,
              });
            }
          })
        );
      })
    );

    await Promise.all(
      userData.map(async (c) => {
        if (!lastMessageSenderIds.includes(c.id)) {
          const unReadMessageCount = await knex("chat_history")
            .where("receiverId", user.id)
            .where("senderId", c.id)
            .where("isRead", 0);
          lastSenderUser.push({
            ...c,
            unReadMessage: unReadMessageCount.length,
          });
        }
      })
    );
    const data = await firstSenderUser.concat(lastSenderUser);

    let reciverUser = {
      id: null,
      firstName: null,
      lastName: null,
      profilePicture: null,
    };
    if (data.length != 0) {
      reciverUser = await knex("users").where("id", data[0].id).first();
    }
    const groupList = await knex("group_members")
      .select(
        "group_members.id as Ids",
        "group_members.groupId",
        "group_members.userId",
        "groups.id",
        "groups.groupId as groupIds",
        "groups.name",
        "groups.groupIcon",
        knex.raw(
          "(SELECT COUNT(id) FROM group_members WHERE groupId = groups.id) as groupMembers"
        )
      )
      .leftJoin("groups", "groups.id", "group_members.groupId")
      .where("group_members.userId", req.user.id);

    const allMessages = await knex
      .select("*")
      .from("chat_history")
      .where("senderId", user.id)
      .andWhere("receiverId", reciverUser.id)
      .union(function async() {
        this.select("*")
          .from("chat_history")
          .where("senderId", reciverUser.id)
          .andWhere("receiverId", user.id);
      })
      .orderBy("id", "desc");
    // .paginate({
    //   perPage: 10,
    //   currentPage: 1,
    //   isLengthAware: true,
    // });

    const groupData = [];
    await Promise.all(
      groupList.map(async (glist) => {
        const unReadMessage = [];
        const messagelist = await knex("chat_history")
          .where("groupId", glist.id)
          .limit(50)
          .orderBy("id", "desc");

        await Promise.all(
          messagelist.map(async (groupMessage) => {
            const messageSeenUser = groupMessage.groupMessageSeen
              ? groupMessage.groupMessageSeen.split(",")
              : [];
            var numberArray = [];

            for (var i = 0; i < messageSeenUser.length; i++) {
              numberArray.push(parseInt(messageSeenUser[i]));
            }
            if (!numberArray.includes(user.id)) {
              unReadMessage.push(groupMessage);
            }
          })
        );
        groupData.push({ ...glist, unReadMessage: unReadMessage.length });
      })
    );

    return res.render("home/index", {
      user: user,
      userList: data,
      senderId: user.id,
      reciverUser: reciverUser,
      allMessages: allMessages,
      groupList: groupData,
    });
  }

  /**
   * Home user chat
   * @param {*} req
   * @param {*} res
   */
  async homeChatUse(req, res) {
    const user = await knex("users").where("id", req.user.id).first();

    const userData = await knex("users").whereNot("id", req.user.id);

    const lastMessageSenderUser = await knex("chat_history")
      .where("receiverId", user.id)
      .pluck("senderId")
      .orderBy("id", "desc");

    const lastMessageSenderIds = [];
    const firstSenderUser = [];
    const lastSenderUser = [];

    await Promise.all(
      lastMessageSenderUser.map(async (k) => {
        if (!lastMessageSenderIds.includes(k)) {
          lastMessageSenderIds.push(k);
        }
      })
    );

    await Promise.all(
      lastMessageSenderIds.map(async (a) => {
        await Promise.all(
          userData.map(async (b) => {
            if (a === b.id) {
              const unReadMessageCount = await knex("chat_history")
                .where("receiverId", user.id)
                .where("senderId", b.id)
                .where("isRead", false);
              firstSenderUser.push({
                ...b,
                unReadMessage: unReadMessageCount.length,
              });
            }
          })
        );
      })
    );

    await Promise.all(
      userData.map(async (c) => {
        if (!lastMessageSenderIds.includes(c.id)) {
          const unReadMessageCount = await knex("chat_history")
            .where("receiverId", user.id)
            .where("senderId", c.id)
            .where("isRead", 0);
          lastSenderUser.push({
            ...c,
            unReadMessage: unReadMessageCount.length,
          });
        }
      })
    );

    const data = await firstSenderUser.concat(lastSenderUser);

    const groupList = await knex("group_members")
      .select(
        "group_members.id as Ids",
        "group_members.groupId",
        "group_members.userId",
        "groups.id",
        "groups.groupId as groupIds",
        "groups.name",
        "groups.groupIcon",
        knex.raw(
          "(SELECT COUNT(id) FROM group_members WHERE groupId = groups.id) as groupMembers"
        )
      )
      .leftJoin("groups", "groups.id", "group_members.groupId")
      .where("group_members.userId", req.user.id);

    const reciverUser = await knex("users")
      .where("userId", req.params.id)
      .first();

    //   const allmes = await knex
    //   .select("*")
    //   .from("chat_history")
    //   .where("senderId", user.id)
    //   .andWhere("receiverId", reciverUser.id)
    //   .union(function async() {
    //     this.select("*")
    //       .from("chat_history")
    //       .where("senderId", reciverUser.id)
    //       .andWhere("receiverId", user.id);
    //   })
    //   .orderBy("id", "desc")
    //   .paginate({
    //     perPage: 50,
    //     currentPage: 1,
    //     isLengthAware: true,
    //   });

    // const allMessages = [];
    // await Promise.all(
    //   allmes.data.map(async (a) => {
    //     const date = await moment(a.messgeCreatedAt).format("DD MMM, HH:mm");
    //     let viewDate = await moment(a.messgeCreatedAt).format("MMM DD YYYY");
    //     const today = await moment().format("DD MM YYYY");
    //     const yesterDay = await moment()
    //       .subtract(1, "day")
    //       .format("DD MM YYYY");
    //     const messageDate = await moment(a.messgeCreatedAt).format(
    //       "DD MM YYYY"
    //     );
    //     if (today === messageDate) {
    //       viewDate = "TODAY";
    //     }
    //     if (yesterDay === messageDate) {
    //       viewDate = "YESTERDAY";
    //     }
    //     allMessages.push({
    //       ...a,
    //       date: date,
    //       messageDate: messageDate,
    //       viewDate: viewDate,
    //     });
    //   })
    // );

    const groupData = [];
    await Promise.all(
      groupList.map(async (glist) => {
        const unReadMessage = [];
        const messagelist = await knex("chat_history")
          .where("groupId", glist.id)
          .limit(50)
          .orderBy("id", "desc");
        await Promise.all(
          messagelist.map(async (groupMessage) => {
            const messageSeenUser = groupMessage.groupMessageSeen
              ? groupMessage.groupMessageSeen.split(",")
              : [];
            var numberArray = [];

            for (var i = 0; i < messageSeenUser.length; i++) {
              numberArray.push(parseInt(messageSeenUser[i]));
            }
            if (!numberArray.includes(user.id)) {
              unReadMessage.push(groupMessage);
            }
          })
        );
        groupData.push({ ...glist, unReadMessage: unReadMessage.length });
      })
    );

    return res.render("home/chat", {
      user: user,
      userList: data,
      senderId: user.id,
      reciverUser: reciverUser,
      // allMessages: allMessages,
      groupList: groupData,
    });
  }

  /**
   * Group chat
   * @param {*} req
   * @param {*} res
   */
  async groupChatUse(req, res) {
    const user = await knex("users").where("id", req.user.id).first();
    const userData = await knex("users").whereNot("id", req.user.id);
    const lastMessageSenderUser = await knex("chat_history")
      .where("receiverId", user.id)
      .pluck("senderId")
      .orderBy("id", "desc");
    const lastMessageSenderIds = [];
    const firstSenderUser = [];
    const lastSenderUser = [];

    await Promise.all(
      lastMessageSenderUser.map(async (k) => {
        if (!lastMessageSenderIds.includes(k)) {
          lastMessageSenderIds.push(k);
        }
      })
    );
    await Promise.all(
      lastMessageSenderIds.map(async (a) => {
        await Promise.all(
          userData.map(async (b) => {
            if (a === b.id) {
              const unReadMessageCount = await knex("chat_history")
                .where("receiverId", user.id)
                .where("senderId", b.id)
                .where("isRead", false);
              firstSenderUser.push({
                ...b,
                unReadMessage: unReadMessageCount.length,
              });
            }
          })
        );
      })
    );

    await Promise.all(
      userData.map(async (c) => {
        if (!lastMessageSenderIds.includes(c.id)) {
          const unReadMessageCount = await knex("chat_history")
            .where("receiverId", user.id)
            .where("senderId", c.id)
            .where("isRead", 0);
          lastSenderUser.push({
            ...c,
            unReadMessage: unReadMessageCount.length,
          });
        }
      })
    );

    const data = await firstSenderUser.concat(lastSenderUser);

    const groupList = await knex("group_members")
      .select(
        "group_members.id as Ids",
        "group_members.groupId",
        "group_members.userId",
        "groups.id",
        "groups.groupId as groupIds",
        "groups.name",
        "groups.groupIcon",
        knex.raw(
          "(SELECT COUNT(id) FROM group_members WHERE groupId = groups.id) as groupMembers"
        )
      )
      .leftJoin("groups", "groups.id", "group_members.groupId")
      .where("group_members.userId", req.user.id);
    const group = await knex("groups").where("groupId", req.params.id).first();
    const groupMembers = await knex("group_members").where("groupId", group.id);

    // const allmes = await knex("chat_history")
    //   .select(
    //     "chat_history.id",
    //     "chat_history.senderId",
    //     "chat_history.groupId",
    //     "chat_history.message",
    //     "chat_history.filePath",
    //     "chat_history.messageType",
    //     "chat_history.fileSize",
    //     "chat_history.createdAt",
    //     "chat_history.messgeCreatedAt",
    //     "users.firstName",
    //     "users.lastName",
    //     "users.profilePicture"
    //   )
    //   .leftJoin("users", "users.id", "chat_history.senderId")
    //   .where("chat_history.groupId", group.id)
    //   .orderBy("id", "desc")
    //   .paginate({
    //     perPage: 50,
    //     currentPage: 1,
    //     isLengthAware: true,
    //   });
    // const messageList = [];
    // await Promise.all(
    //   allmes.data.map(async (a) => {
    //     const date = await moment(a.messgeCreatedAt).format("DD MMM, HH:mm");
    //     let viewDate = await moment(a.messgeCreatedAt).format("MMM DD YYYY");
    //     const today = await moment().format("DD MM YYYY");
    //     const yesterDay = await moment()
    //       .subtract(1, "day")
    //       .format("DD MM YYYY");
    //     const messageDate = await moment(a.messgeCreatedAt).format(
    //       "DD MM YYYY"
    //     );
    //     if (today === messageDate) {
    //       viewDate = "TODAY";
    //     }
    //     if (yesterDay === messageDate) {
    //       viewDate = "YESTERDAY";
    //     }
    //     messageList.push({
    //       ...a,
    //       date: date,
    //       messageDate: messageDate,
    //       viewDate: viewDate,
    //     });
    //   })
    // );

    const groupData = [];
    await Promise.all(
      groupList.map(async (glist) => {
        const unReadMessage = [];
        const messagelist = await knex("chat_history")
          .where("groupId", glist.id)
          .limit(50)
          .orderBy("id", "desc");
        await Promise.all(
          messagelist.map(async (groupMessage) => {
            const messageSeenUser = groupMessage.groupMessageSeen
              ? groupMessage.groupMessageSeen.split(",")
              : [];
            var numberArray = [];

            for (var i = 0; i < messageSeenUser.length; i++) {
              numberArray.push(parseInt(messageSeenUser[i]));
            }
            if (!numberArray.includes(user.id)) {
              unReadMessage.push(groupMessage);
            }
          })
        );
        groupData.push({ ...glist, unReadMessage: unReadMessage.length });
      })
    );

    return res.render("home/group", {
      user: user,
      userList: data,
      senderId: user.id,
      group: group,
      // allMessages: messageList,
      groupList: groupData,
      groupMembers: groupMembers.length,
    });
  }

  /**
   * chat message list
   * @param {*} req
   * @param {*} res
   */
  async messageList(req, res) {
    const reciverUser = await knex("users").where("id", req.params.id).first();
    const allmes = await knex
      .select("*")
      .from("chat_history")
      .where("senderId", req.user.id)
      .andWhere("receiverId", reciverUser.id)
      .union(function async() {
        this.select("*")
          .from("chat_history")
          .where("senderId", reciverUser.id)
          .andWhere("receiverId", req.user.id);
      })
      .orderBy("id", "desc")
      .paginate({
        perPage: 50,
        currentPage: 1,
        isLengthAware: true,
      });

    const allMessages = [];
    await Promise.all(
      allmes.data.map(async (a) => {
        const date = await moment(a.messgeCreatedAt).format("DD MMM, HH:mm");
        let viewDate = await moment(a.messgeCreatedAt).format("MMM DD YYYY");
        const today = await moment().format("DD MM YYYY");
        const yesterDay = await moment()
          .subtract(1, "day")
          .format("DD MM YYYY");
        const messageDate = await moment(a.messgeCreatedAt).format(
          "DD MM YYYY"
        );
        if (today === messageDate) {
          viewDate = "TODAY";
        }
        if (yesterDay === messageDate) {
          viewDate = "YESTERDAY";
        }
        allMessages.push({
          ...a,
          date: date,
          messageDate: messageDate,
          viewDate: viewDate,
        });
      })
    );

    return res.json({
      data: allMessages,
    });
  }

  /**
   * Group message List
   * @param {*} req
   * @param {*} res
   */
  async groupMaessageList(req, res) {
    const allmes = await knex("chat_history")
      .select(
        "chat_history.id",
        "chat_history.senderId",
        "chat_history.groupId",
        "chat_history.message",
        "chat_history.filePath",
        "chat_history.messageType",
        "chat_history.fileSize",
        "chat_history.createdAt",
        "chat_history.messgeCreatedAt",
        "users.firstName",
        "users.lastName",
        "users.profilePicture"
      )
      .leftJoin("users", "users.id", "chat_history.senderId")
      .where("chat_history.groupId", parseInt(req.params.id))
      .orderBy("id", "desc")
      .paginate({
        perPage: 50,
        currentPage: 1,
        isLengthAware: true,
      });
    const messageList = [];
    await Promise.all(
      allmes.data.map(async (a) => {
        const date = await moment(a.messgeCreatedAt).format("DD MMM, HH:mm");
        let viewDate = await moment(a.messgeCreatedAt).format("MMM DD YYYY");
        const today = await moment().format("DD MM YYYY");
        const yesterDay = await moment()
          .subtract(1, "day")
          .format("DD MM YYYY");
        const messageDate = await moment(a.messgeCreatedAt).format(
          "DD MM YYYY"
        );
        if (today === messageDate) {
          viewDate = "TODAY";
        }
        if (yesterDay === messageDate) {
          viewDate = "YESTERDAY";
        }
        messageList.push({
          ...a,
          date: date,
          messageDate: messageDate,
          viewDate: viewDate,
        });
      })
    );
    return res.json({
      data: messageList,
    });
  }
}
export default new HomeController();
