$(function() {

	$('select[multiple].active.3col').multiselect({
	  columns: 1,
	  placeholder: 'Select User',
	  search: true,
	  searchOptions: {
	      'default': 'Search User'
	  },
	  selectAll: true
	});

});


