const staticCacheName = 'pre-cache-v2.6.0';
const dynamicCacheName = 'runtime-cache-v2.6.0';

const precacheAssets = ['/'];

self.addEventListener('install', function (event) {
    event.waitUntil(
        caches.open(staticCacheName).then(function (cache) {
            return cache.addAll(precacheAssets);
        })
    );
});